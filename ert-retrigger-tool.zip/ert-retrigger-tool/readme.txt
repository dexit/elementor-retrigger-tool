=== ERT Re-Trigger Tool ===
Contributors: dexit
Tags: elementor, form, submission, retrigger, webhook
Requires at least: 6.0
Tested up to: 6.8
Stable tag: 1.0.1
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Bulk re-trigger form actions (Webhooks, Emails) and edit submission payloads. Compatible with Elementor Pro.

== Description ==

Have you ever had a Webhook fail (Zapier/Make/HubSpot) and lost critical leads? This plugin allows you to re-execute "Actions After Submit" for past form submissions.

**Key Features:**
*   **Bulk Re-Trigger:** Select multiple submissions and re-run actions in a queue.
*   **Edit Payload:** Modify submission data before re-sending (creates a new submission record).
*   **Visual Queue:** Watch the progress of your re-triggering tasks.
*   **Detailed Logs:** View full JSON payloads and HTTP error codes for failed webhooks.
*   **Auto-Cleanup:** Automatically cleans up logs to keep your database optimized.

**Requirements:**
*   Elementor Pro (Active)

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/ert-retrigger-tool` directory.
2. Activate the plugin through the 'Plugins' screen.
3. Go to **Elementor > Re-Trigger Tool** to start using it.

== Screenshots ==

1. The main interface with bulk selection and visual queue.
2. The logs tab showing detailed webhook responses.
3. The edit payload modal.
4. Settings page for log retention.
5. Filter submissions by form name.
6. Filter submissions by date.
7. Search submissions by ID or Email.
8. Visual queue processing items.

== Changelog ==

= 1.0.1 =
* Security fixes and repository compliance updates.

= 1.0.0 =
* Initial release.